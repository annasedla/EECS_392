//
//  ValueStorage.swift
//  BlackJack
//
//  Created by Anna Sedlackova on 3/19/18.
//  Copyright © 2018 Jing Li. All rights reserved.
//

import UIKit

class ValueStorage: UIView {

    /*
        VARIABLES AND FIELDS
    */
    
    //Stores number of decks
    static var nOfDecks : Int?
    
    //stores number of cards
    static var minCards : Int?
    
    /*
        GETTER AND SETTER METHODS
     */
    
    static func getNOfDecks() -> Int{
        if (nOfDecks != nil){
            return nOfDecks!
        }else{
            return 1
        }
    }
    
    static func getMinCards() -> Int{
        if (minCards != nil){
            return minCards!
        }else{
            return 13
        }
    }
    
}
