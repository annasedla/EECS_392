//
//  BJModel.swift
//  BlackJack
//
//  Created by Anna Sedlackova on 2/20/18.
//  Copyright © 2018 Jing Li. All rights reserved.
//

import Foundation
import UIKit

enum Suit: Int {
    case club = 0, spade, diamond, heart
    func simpleDescription() -> String{
        switch self {
        case .club:
            return "club"
        case .spade:
            return "spade"
        case .diamond:
            return "diamond"
        case .heart:
            return "heart"
        }
    }
}

class Card {
    var suit: Suit = .club
    var digit = 1
    var isFaceUp = true
    
    init(suit: Suit, digit: Int){
        self.suit = suit
        self.digit = digit
    }
    
    static func generateAPackOfCards() -> [Card]{
        var deckOfCard = [Card]()
        for i in 0..<4{
            for j in 1...13{
                deckOfCard.append(Card(suit: Suit(rawValue: i)!, digit: j))
                
            }
        }
        return deckOfCard
    }
    
    func getCardImage() -> UIImage? {
        if isFaceUp{
            return UIImage(named: "\(suit.simpleDescription())-\(digit).png")
        }else{
            return UIImage(named: "card-back.png")
        }
    }
    
    func isAce() -> Bool {
        return digit == 1 ? true : false
    }
    func isAFaceOrTen() -> Bool {
        return digit > 9 ? true : false
    }
}

enum BJGameStage: Int{
    case playerStage = 0
    case dealerStage, gameOverStage
}

extension Array{
    mutating func shuffle(){
        for i in 0...(self.count-1){
            let tmpInt =  i+1
            let j = Int(arc4random_uniform(UInt32(tmpInt)))
            let tmp = self[i]
            self[i] = self[j]
            self[j] = tmp
        }
    }
}





/* BJ GAME MODEL*/
class BJGameModel{
    private var cards = [Card]()
    private static var numCards: Int!
    private var playerCards = [Card]()
    private var dealerCards = [Card]()
    var gameStage : BJGameStage = .playerStage
    
    //let treshold = 13 //added
    
    let maxPlayerCards = 5
    var didDealerWin = false
    
    init(){
        if (BJGameModel.returnNumCards() > ValueStorage.getMinCards() ){
            resetGame()
        } else {
            continueGame()
        }
    }
    
    /* QUESTION 3A */
    func continueGame(){
        playerCards = [Card]()
        dealerCards = [Card]()
        gameStage = .playerStage
    }
    
    func resetGame(){
        if (BJGameModel.returnNumCards() > ValueStorage.getMinCards()){
            continueGame()
        } else {
        //cards = Card.generateAPackOfCards()
        cards = BJGameModel.generateMultipleDecks(m: BJGameModel.getDecks())
        BJGameModel.numCards = cards.count //added
        
        //shuffle
        cards.shuffle()
        playerCards = [Card]()
        dealerCards = [Card]()
        gameStage = .playerStage
        }
    }
    
    //func
    
    func newGame(){
    //cards = Card.generateAPackOfCards()
        cards = BJGameModel.generateMultipleDecks(m: BJGameModel.getDecks())
        BJGameModel.numCards = cards.count //added
    
        //shuffle
        cards.shuffle()
        playerCards = [Card]()
        dealerCards = [Card]()
        gameStage = .playerStage
    }
    
    func nextDealerCard() -> Card{
        let card = cards.removeFirst()
        dealerCards.append(card)
        
        BJGameModel.numCards = BJGameModel.numCards - 1 //added
        return card
    }
    
    func nextPlayerCard() -> Card{
        let card = cards.removeFirst()
        playerCards.append(card)
        
        BJGameModel.numCards = BJGameModel.numCards - 1 //added
        return card
    }
    
    func dealerCardAtIndex(i: Int) ->Card?{
        if i < dealerCards.count{
            return dealerCards[i]
        }else{
            return nil
        }
    }
    func playerCardAtIndex(i: Int) ->Card?{
        if i < playerCards.count{
            return playerCards[i]
        }else{
            return nil
        }
    }
    
    func areCardsBust(_ curCards: [Card]) -> Bool{
        var lowestScore = 0
        for card in curCards{
            if card.isAce(){
                lowestScore += 1
            }else if card.isAFaceOrTen(){
                lowestScore += 10
            }else {
                lowestScore += card.digit
            }
        }
        return lowestScore > 21 ? true : false
    }
    
    /*
     QUESTION 3A
     */
    static func returnNumCards() -> Int{
        if (BJGameModel.numCards == nil){
            return 0
        } else {
            return BJGameModel.numCards;
        }
        
    }
    
    /*
     QUESTION 3A
     */
    static func generateMultipleDecks(m: Int) -> Array<Card>{
        var multipleDecks: [Card] = []
        
        for _ in 0..<m{
            let newPack = Card.generateAPackOfCards()
            for card in newPack{
                multipleDecks.append(card)
            }
        }
        
        return multipleDecks
    }
    
    /*
     QUESTION 3A
     */
    static func getDecks() -> Int{
        return ValueStorage.getNOfDecks()
    }
    
    /*
     QUESTION 3B
     */
    
    func isBlackJack(_ curCards: [Card]) -> Bool{
        var lowestScore = 0
        for card in curCards{
            if card.isAce(){
                lowestScore += 1
            }else if card.isAFaceOrTen(){
                lowestScore += 10
            }else {
                lowestScore += card.digit
            }
        }
        return lowestScore == 21 ? true : false
    }
    
    func calculateBestScore(_ curCards: [Card]) -> Int {
        if areCardsBust(curCards) {
            return 0
        }
        var higestScore = 0
        for card in curCards{
            if card.isAce(){
                higestScore += 11
            }else if card.isAFaceOrTen(){
                higestScore += 10
            }else {
                higestScore += card.digit
            }
        }
        while higestScore > 21 {
            higestScore -= 10
        }
        return higestScore
    }
    
    func notifyGameDidEnd(){
        NotificationCenter.default.post(name: Notification.Name(rawValue:"BJNotificationGameDidEnd"), object: self, userInfo: ["didDealerWin" : didDealerWin])
    }
    
    func updateGameStage()  {
        if gameStage == .playerStage{
            
            if isBlackJack(playerCards){ //if blackjack player wins
                gameStage = .gameOverStage
                didDealerWin = false
                //play again
                notifyGameDidEnd()
            }
            
            if areCardsBust(playerCards){
                gameStage = .gameOverStage
                didDealerWin = true
                //play again somehow
                notifyGameDidEnd()
                
            }else if playerCards.count == maxPlayerCards {
                gameStage = .dealerStage
                
            }
            
        }else if gameStage == .dealerStage{
            if areCardsBust(dealerCards){
                gameStage = .gameOverStage
                didDealerWin = false
                //play again somehow
                notifyGameDidEnd()
            }else if dealerCards.count == maxPlayerCards{
                gameStage = .gameOverStage
                calcualteWinner()
                //play again somehow
                notifyGameDidEnd()
            }else{
                let dealerScore = calculateBestScore(dealerCards)
                if dealerScore < 17 {
                    //do nothing, still dealer's turn
                }else{
                    let playerScore = calculateBestScore(playerCards)
                    if playerScore > dealerScore{
                        //do nothing
                    }else{
                        didDealerWin = true
                        gameStage = .gameOverStage
                        //play again somehow
                        notifyGameDidEnd()
                    }
                }
            }
            
        }else{
            calcualteWinner()
            notifyGameDidEnd()
        }
    }
    
    func calcualteWinner(){
        let dealerScore = calculateBestScore(dealerCards)
        let playerScore = calculateBestScore(playerCards)
        didDealerWin = dealerScore >= playerScore
    }
    
    
}
