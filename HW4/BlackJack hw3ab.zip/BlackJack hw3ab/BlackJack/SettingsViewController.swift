//
//  SettingsViewController.swift
//  BlackJack
//
//  Created by Anna Sedlackova on 3/18/18.
//  Copyright © 2018 Jing Li. All rights reserved.
//

import UIKit

class SettingsViewController: UIViewController,UITextFieldDelegate {
    
    /*
     VARIABLES AND FIELDS
     */
    //variable that controls buttons
     var isEdit: Bool = true
     var tempNOfDecks: Int = 1
     var tempMinCards: Int = 13
    
    
   // private var gameModel: BJGameModel

    @IBOutlet weak var editDoneButton: UIBarButtonItem!
    
    //field to enter number of decks
    @IBOutlet weak var nOfDecks: UITextField!{
        didSet{
            nOfDecks.delegate = self as! UITextFieldDelegate
        }
    }
    
    //field to enter mimimum cards to play
    @IBOutlet weak var minCards: UITextField!{
        didSet{
            minCards.delegate = self as! UITextFieldDelegate
        }
    }
    
    /*
        BUTTON FUNCTIONS
    */
    //exit out of the settings view 
    @IBAction func editDoneButton(_ sender: UIBarButtonItem) {
        if isEdit { //editing mode
            self.canEdit()
            isEdit = false
            self.navigationItem.leftBarButtonItem?.title = "Done";
            nOfDecks.isEnabled = true
            minCards.isEnabled = true
        } else { //done mode
            self.view.endEditing(true)
            ValueStorage.nOfDecks = tempNOfDecks
            ValueStorage.minCards = tempMinCards
            self.dismiss(animated: true, completion: nil)
            //gameModel.resetGame()
            isEdit = true

        }
        //self.navigationItem.leftBarButtonItem = self.editButtonItem;
    }
    
    @objc func canEdit(){
        nOfDecks.placeholder = (String(ValueStorage.getNOfDecks()))
        minCards.placeholder = (String(ValueStorage.getMinCards()))
    }
    
    @IBAction func cancelButton(_ sender: UIBarButtonItem) {
        self.dismiss(animated: true, completion: nil)
    }
    
    //save values in variables for viewController
    func textFieldDidEndEditing(_ textField: UITextField) {
        textField.resignFirstResponder()
        if let tmp = textField.text{
            switch(textField){
            case nOfDecks:
                tempNOfDecks = Int(tmp)!
            case minCards:
                tempMinCards = Int(tmp)!
            default:
                break
            }
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    

    /*
        DEFAULT FUNCTIONS
     */
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.navigationItem.leftBarButtonItem?.title = "Edit";
        nOfDecks.isEnabled = false
        minCards.isEnabled = false
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
}
